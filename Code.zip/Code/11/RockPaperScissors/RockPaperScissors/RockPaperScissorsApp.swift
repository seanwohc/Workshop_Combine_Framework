//
//  RockPaperScissorsApp.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/21/20.
//

import SwiftUI

@main
struct RockPaperScissorsApp: App {
    var body: some Scene {
        WindowGroup {
            GameView()
        }
    }
}
