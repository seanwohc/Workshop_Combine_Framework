//
//  Hand.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//

import Combine
import Foundation

class Hand {
  @Published var handPosition: HandPosition = .rock
  
  lazy private(set) var imageName: AnyPublisher<String, Never>
    = $handPosition
    .dropFirst()
    .map(\.imageName)
    .receive(on: RunLoop.main)
    .eraseToAnyPublisher()
}
