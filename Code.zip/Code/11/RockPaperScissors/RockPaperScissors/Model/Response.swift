//
//  Response.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//
import Combine
import Foundation

class Response: Hand {
  private var cancellable: AnyCancellable?

  
  func nextPosition() {
    guard let randomIntURL = intURL() else {return}
    cancellable
      = URLSession.shared
      .dataTaskPublisher(for: randomIntURL)
      .map(\.data)
      .compactMap {data in
        String(data: data,
               encoding: .utf8)
      }
      .compactMap {string in
        Int(string)
      }
      .sink(receiveCompletion: {completion in
        switch completion {
        case .finished:
          print("finished")
        case .failure(let error):
          print("error in datatask:", error)
        }
      }, receiveValue: {int in
        self.handPosition = setHandPosition(for: int)
      })
  }
}
