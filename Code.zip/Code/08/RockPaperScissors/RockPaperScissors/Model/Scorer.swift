//
//  Scorer.swift
//  RockPaperScissors
//
//  Created by Sean Espressoft on 18/01/2021.
//

import Foundation
import Combine

struct Scorer {
    let player: Player
    let response: Response
    
    lazy private(set) var result : AnyPublisher<GameResult, Never>
        = player.$handPosition // Pub<HP, Never>
        .zip(response.$handPosition) // Pub<[HP,HP], Never>
        .dropFirst()
        .map(gameResult)
        .receive(on: RunLoop.main)
        .eraseToAnyPublisher()
}
