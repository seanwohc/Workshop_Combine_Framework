//
//  Response.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//

import Combine
import Foundation

class Response: Hand {
    
    private var cancellable: AnyCancellable?
    
    @Published private var int = 0
    
    override init() {
        super.init()
        tenRemover()
    }
    
    func nextPosition() {
        int = .random(in: 1...100)
    }
    
    private func tenRemover(){
        $int
            .dropFirst()
            .print("Before map")
            .flatMap{ int in
                Just(int)
                    .tryMap(self.restrictedPosition) //Pub<HandPosition, DivisibleByTen>
                .catch{error in
                    Just(randomHandPosition())
                }
            }
            .print("After catch")
            .assign(to: &$handPosition)
    }
    
    //Alternative
//    .flatMap { int0 -> Just<HandPosition> in
//                    do {
//                        return Just(try self.restrictedPosition(from: int0))
//                    } catch {
//                        return Just(randomHandPosition())
//                    }
//                }
//
//  func nextPosition() {
////    handPosition = randomHandPosition()
//    guard let randomIntURL = handPositionURL() else {return}
//    cancellable =
//        URLSession.shared.dataTaskPublisher(for: randomIntURL) //Pub<(Data, URLResponse, Error>
//        .map(\.data)    //Pub<Data, Error>
//        .decode(type: RandomPosition.self, decoder: JSONDecoder())
//        .print("Error Received")
//        .catch{ (error) in
//            Just(RandomPosition(position: randomHandPosition()))
//        }
//        .sink(receiveCompletion: { (completion) in //Sink <RandPosition, Never>
//            switch completion {
//            case .finished:
//                print("Finished")
//            case .failure(let error):
//                print("Failed", error)
//            }
//        }, receiveValue: { [weak self]  (randPosition) in
//            self?.handPosition = randPosition.position
//        })
////        .compactMap{data in // Pub <String, Error>
////            String(data: data, encoding: .utf8)
////        }
////        .compactMap{string in // Pub <Int, Error>
////            Int(string)
////        }
////        .sink(receiveCompletion: { completion in //Subs<Int, Error>
////            switch completion {
////            case .finished:
////                print("Finished")
////            case .failure(let error):
////                print("Failed", error)
////            }
////        }, receiveValue: {[weak self] int in
////            self?.handPosition = setHandPosition(for: int)
////        })
//  }
}


struct RandomPosition: Codable{
    let position: HandPosition
}

