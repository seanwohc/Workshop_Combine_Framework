//
//  Hand.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//

import Combine
import Foundation

class Hand {
  @Published var handPosition: HandPosition = .rock
    
    lazy private(set) var imageName: AnyPublisher<String, Never> =
    $handPosition //Pub<HP, Never>
    .dropFirst() //Pub<HP, Never>
    .map(\.imageName) //Pub<String, Never>
    .receive(on: RunLoop.main)
    .eraseToAnyPublisher()
}
