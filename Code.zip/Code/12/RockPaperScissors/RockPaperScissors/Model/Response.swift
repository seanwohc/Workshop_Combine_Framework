//
//  Response.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//
import Combine
import Foundation

class Response: Hand {
  private var cancellable: AnyCancellable?
  
  func nextPosition() {
    handPosition = randomHandPosition()
  }
  
  func next() {
    guard let randomPositionURL = handPositionURL() else {return}
    cancellable
      = URLSession.shared
      .dataTaskPublisher(for: randomPositionURL)
      .map(\.data)
      .decode(type: RandomPosition.self,
              decoder: JSONDecoder())
      .sink(receiveCompletion: {completion in
        switch completion {
        case .finished:
          print("finished")
        case .failure(let error):
          print("error in JSON decoding:", error)
        }
      }, receiveValue: {randomPosition in
        self.handPosition = randomPosition.position
      })
  }
}
