//
//  HandPosition.swift Copyright Dim Sum Thinking
//

struct RandomPosition: Codable {
  let position: HandPosition
}

enum HandPosition: String, CaseIterable, Codable {
  case rock
  case paper
  case scissors
}

extension HandPosition: CustomStringConvertible {
  var description: String {
    rawValue.capitalized
  }
}

extension HandPosition {
  var imageName: String {
    switch self {
    case .rock:
      return "speedometer"
    case .paper:
      return "paperplane"
    case .scissors:
      return "scissors"
    }
  }
}

extension HandPosition: Equatable, Comparable {
    static func < (lhs: HandPosition, rhs: HandPosition) -> Bool {
        switch (lhs, rhs) {
        case (.rock, .paper),
             (.paper, .scissors),
             (.scissors, .rock):
            return true
        default:
            return false
        }
    }
}

let handPositions = HandPosition.allCases
let numberOfHandPositions = handPositions.count

func setHandPosition(for index: Int) -> HandPosition {
  assert((0...numberOfHandPositions).contains(index),
         "Input must be between 0 and \(numberOfHandPositions)")
  return handPositions[index]
}

func randomHandPosition() -> HandPosition {
  return handPositions.randomElement()!
}
