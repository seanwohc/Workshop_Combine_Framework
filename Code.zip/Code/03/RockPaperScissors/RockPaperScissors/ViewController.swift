//
//  ViewController.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//

import UIKit
import Combine

class ViewController: UIViewController {
  @IBOutlet private weak var resultView: UIImageView!
  @IBOutlet private weak var playerView: UIImageView!
  @IBOutlet private weak var responseView: UIImageView!
  @IBOutlet private weak var playerSelector: UISegmentedControl!
  private var cancellable: AnyCancellable?
  private let game = Game()
  
  override func viewDidLoad() {
    super.viewDidLoad()
    cancellable =
      NotificationCenter
      .default
      .publisher(for: Notification.Name("player"))
      .sink{[weak self] notification in
        guard let player = notification.object as? Player else {return}
        self?.playerView.image = UIImage(systemName: player.handPosition.imageName)
      }
  }
    
  @IBAction func enterChoice(_ button: UIButton) {
    game.setPlayer(playerSelector.selectedSegmentIndex)
  }
}

