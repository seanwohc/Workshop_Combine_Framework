//
//  Response.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//

class Response: Hand {
  func nextPosition() {
    handPosition = randomHandPosition()
  }
}
