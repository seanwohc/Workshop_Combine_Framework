//
//  GameResult.swift Copyright Dim Sum Thinking
//

import SwiftUI

enum GameResult {
    case win
    case lose
    case draw
}

extension GameResult {
    var imageColor: Color {
        switch self {
        case .win:
            return .green
        case .lose:
            return .red
        case .draw:
            return .secondary
        }
    }
    
    var imageName: String {
        switch self {
        case .win:
            return "hand.thumbsup"
        case .lose:
            return "hand.thumbsdown"
        case .draw:
            return "questionmark"
        }
    }
}

func gameResult(for first: HandPosition,
                against second: HandPosition) -> GameResult {
    if first == second { return .draw}
    else if first < second {return .lose}
    return .win
}

import UIKit

extension GameResult {
  var uiImageColor: UIColor {
    UIColor(imageColor)
  }
}

