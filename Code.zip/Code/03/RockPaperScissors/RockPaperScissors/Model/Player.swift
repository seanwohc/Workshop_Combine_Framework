//
//  Player.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//

class Player: Hand {
  func setPosition(to int: Int) {
    handPosition = setHandPosition(for: int)
  }
}
