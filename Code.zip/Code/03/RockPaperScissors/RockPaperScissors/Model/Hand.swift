//
//  Hand.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//

import Foundation

class Hand {
  var handPosition: HandPosition = .rock {
    didSet {
      NotificationCenter
        .default
        .post(name: NSNotification.Name("player"),
              object: self)
    }
  }
}
