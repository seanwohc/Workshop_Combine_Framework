//
//  Game.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//

class Game {
  private let player = Player()
  private let response = Response()
}

extension Game {
  func setPlayer(_ int: Int){
    player.setPosition(to: int)
  }
}
