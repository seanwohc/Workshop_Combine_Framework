//
//  ViewController.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//

import UIKit
import Combine

class ViewController: UIViewController {
  @IBOutlet private weak var resultView: UIImageView!
  @IBOutlet private weak var playerView: UIImageView!
  @IBOutlet private weak var responseView: UIImageView!
  @IBOutlet private weak var playerSelector: UISegmentedControl!
  @Published private var playerChoice = 0
  private var cancellable: AnyCancellable?
  
  override func viewDidLoad() {
    super.viewDidLoad()
    cancellable =
      $playerChoice
      .dropFirst()
      .sink{[weak self] int in
        let player = setHandPosition(for: int)
        self?.playerView.image = UIImage(systemName: player.imageName)
      }
  }
    
  @IBAction func enterChoice(_ button: UIButton) {
    playerChoice = playerSelector.selectedSegmentIndex
  }
}

