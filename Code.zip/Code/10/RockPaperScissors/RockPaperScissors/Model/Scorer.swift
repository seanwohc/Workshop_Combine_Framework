//
//  Scorer.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/21/20.
//
import Combine
import Foundation

struct Scorer {
  let player: Player
  let response: Response
  
  lazy private(set) var result: AnyPublisher<GameResult, Never>
    = player.$handPosition
    .zip(response.$handPosition)
    .dropFirst()
    .map(gameResult)
    .receive(on: RunLoop.main)
    .eraseToAnyPublisher()
}

