class Response: Hand {
    func nextPosition() {
        handPosition = randomHandPosition()
    }
}
