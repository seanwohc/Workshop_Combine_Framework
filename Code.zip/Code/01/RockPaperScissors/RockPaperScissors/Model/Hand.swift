import Combine

class Hand {
    @Published var handPosition: HandPosition = .rock
}
