class Player: Hand {
    func setPosition(to int: Int) {
        handPosition = setHandPosition(for: int)
    }
}
