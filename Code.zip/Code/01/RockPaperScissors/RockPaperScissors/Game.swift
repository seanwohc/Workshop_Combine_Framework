//
//  Game.swift
//  RockPaperScissors
//
//  Created by Sean Espressoft on 18/01/2021.
//

import Combine
import UIKit

class Game: ObservableObject {
    private let player = Player()
    private let response = Response()

    @Published private(set) var playerImageName: String = "questionmark"
    @Published private(set) var responseImageName: String = "questionmark"
    @Published private(set) var resultImageName: String = "questionmark"
    @Published private(set) var resultImageColor = UIColor.secondaryLabel
    
    init() {
        subscribeToPlayer()
    }
}


extension Game {
    func subscribeToPlayer(){
        player.$handPosition //Pub<HP, NeverFail>
            .dropFirst()
            .receive(on: RunLoop.main)
            .map(\.imageName)
            .assign(to: &$playerImageName)
        
//        Just("sun.dust")
//            .delay(for: 10, scheduler: RunLoop.main)
//            .assign(to: &$responseImageName)
//        Just("arrow.left")
//            .assign(to: &$resultImageName)
    }
}

extension Game {
    func setPlayer(_ int: Int) {
        player.setPosition(to: int)
    }
}
