//
//  Game.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//

import Combine
import UIKit

class Game: ObservableObject {
  private let player = Player()
  private let response = Response()
  @Published private(set) var playerImageName = "questionmark"
  @Published private(set) var responseImageName = "questionmark"
  @Published private(set) var resultImageName = "questionmark"
  @Published private(set) var resultImageColor = UIColor.secondaryLabel

  init() {
    subscribeToPlayer()
  }
}

extension Game {
  func setPlayer(_ int: Int) {
    player.setPosition(to: int)
  }
}

extension Game {
  func subscribeToPlayer() {
    player.$handPosition
      .dropFirst()
      .map(\.imageName)
      .receive(on: RunLoop.main)
      .assign(to: &$playerImageName)
    
    Just("sun.dust")
      .delay(for: 5, scheduler: RunLoop.main)
      .assign(to: &$responseImageName)
  }
}
