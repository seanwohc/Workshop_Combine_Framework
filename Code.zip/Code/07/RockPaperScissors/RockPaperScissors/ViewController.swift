//
//  ViewController.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//

import UIKit
import Combine

class ViewController: UIViewController {
  @IBOutlet private weak var resultView: UIImageView!
  @IBOutlet private weak var playerView: UIImageView!
  @IBOutlet private weak var responseView: UIImageView!
  @IBOutlet private weak var playerSelector: UISegmentedControl!
  private var cancellable: AnyCancellable?
  private var game = Game()
  
  override func viewDidLoad() {
    super.viewDidLoad()
    cancellable =
      game
      .objectWillChange
      .receive(on: RunLoop.main)
      .sink{[weak self] _ in
        guard let self = self else {return}
        self.playerView.image = self.image(self.game.playerImageName)
        self.responseView.image = self.image(self.game.responseImageName)
        self.resultView.image = self.image(self.game.resultImageName)
        self.resultView.tintColor = self.game.resultImageColor
      }
  }
  
  private func image(_ name: String) -> UIImage? {
    UIImage(systemName: name)
  }
  
  @IBAction func enterChoice(_ button: UIButton) {
    game.setPlayer(playerSelector.selectedSegmentIndex)
  }
}

