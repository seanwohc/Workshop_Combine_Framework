//
//  Game.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//

import Combine
import UIKit

class Game {
  private let player = Player()
  private let response = Response()
  private var cancellable: AnyCancellable?
  @Published private(set) var playerImage
    = UIImage(systemName: "questionmark")
  
  init() {
    cancellable = subscribeToPlayer()
  }
}

extension Game {
  func setPlayer(_ int: Int) {
    player.setPosition(to: int)
  }
}

extension Game {
  func subscribeToPlayer() -> AnyCancellable {
    player.$handPosition
      .dropFirst()
      .receive(on: RunLoop.main)
      .sink{[weak self]  handPosition in
        self?.playerImage
          = UIImage(systemName: handPosition.imageName)
      }
  }
}
