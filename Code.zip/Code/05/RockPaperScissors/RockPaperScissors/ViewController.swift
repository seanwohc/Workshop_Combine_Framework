//
//  ViewController.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//

import UIKit
import Combine

class ViewController: UIViewController {
  @IBOutlet private weak var resultView: UIImageView!
  @IBOutlet private weak var playerView: UIImageView!
  @IBOutlet private weak var responseView: UIImageView!
  @IBOutlet private weak var playerSelector: UISegmentedControl!
  private var cancellable: AnyCancellable?
  private let game = Game()
  
  override func viewDidLoad() {
    super.viewDidLoad()
    cancellable =
      game
      .$playerImage
      .assign(to: \.image,
              on: playerView)
  }
    
  @IBAction func enterChoice(_ button: UIButton) {
    game.setPlayer(playerSelector.selectedSegmentIndex)
  }
}

