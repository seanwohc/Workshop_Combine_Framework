//
//  Game.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//

import Combine
import SwiftUI

class Game: ObservableObject {
  private let player = Player()
  private let response = Response()
  private var cancellables = Set<AnyCancellable>()
  @Published private(set) var playerImageName = "questionmark"
  @Published private(set) var responseImageName = "questionmark"
  @Published private(set) var resultImageName = "questionmark"
  @Published private(set) var resultImageColor = Color.secondary

  init() {
    subscribeToPlayer()
    requestResponse().store(in: &cancellables)
    subscribeToResponse()
  }
}

extension Game {
  func setPlayer(_ int: Int) {
    player.setPosition(to: int)
  }
}

extension Game {
  func subscribeToPlayer() {
    player.imageName
      .assign(to: &$playerImageName)
  }
  
  func requestResponse() -> AnyCancellable {
    $playerImageName
      .dropFirst()
      .sink{[weak self] _ in
        self?.response.nextPosition()
      }
  }
  
  func subscribeToResponse() {
    response.imageName
      .assign(to: &$responseImageName)
  }
}
