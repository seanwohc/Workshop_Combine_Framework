//
//  Hand.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//

import Combine

class Hand {
  @Published var handPosition: HandPosition = .rock
}
