//
//  Game.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//

import Combine
import UIKit

class Game {
  private let player = Player()
  private let response = Response()
  @Published private(set) var playerImageName = "questionmark"
  
  
  init() {
    subscribeToPlayer()
  }
}

extension Game {
  func setPlayer(_ int: Int) {
    player.setPosition(to: int)
  }
}

extension Game {
  func subscribeToPlayer() {
    player.$handPosition
      .dropFirst()
      .map(\.imageName)
      .receive(on: RunLoop.main)
      .assign(to: &$playerImageName)
  }
}
