//
//  Response.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//
import Combine
import Foundation


class Response: Hand {
  private var cancellable: AnyCancellable?
  @Published private var int = 0 {
    didSet {
      print("Int set to:", int)
    }
  }
  
  override init() {
    super.init()
    tensRemover()
  }
  
  func nextPosition() {
    int = .random(in: 1...100)
  }
  
  private func tensRemover() {
    $int
      .dropFirst()
      .flatMap {int in
        Just(int)
          .tryMap(self.restrictedPosition)
          .catch {error in
            Just(randomHandPosition())
          }
      }
      .print()
      .assign(to: &$handPosition)
  }
}


