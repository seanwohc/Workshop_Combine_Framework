//
//  URLConstants.swift
//  RockPaperScissors
//
//  Copyright © 2020 Dim Sum Thinking. All rights reserved.
//

import Foundation

fileprivate(set) var urlComponents: URLComponents = {
    var components = URLComponents()
    components.scheme = "https"
    components.host = "rockpaperscissorsserver.herokuapp.com"
    return components
}()


func intURL() -> URL? {
  urlComponents.path = "/random/number"
  return urlComponents.url
}

func handPositionURL() -> URL? {
  urlComponents.path = "/random/handposition"
  return urlComponents.url
}

