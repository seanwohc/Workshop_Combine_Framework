//
//  ViewController.swift
//  RockPaperScissors
//
//  Created by Daniel Steinberg on 10/20/20.
//

import UIKit

class ViewController: UIViewController {
  @IBOutlet private weak var resultView: UIImageView!
  @IBOutlet private weak var playerView: UIImageView!
  @IBOutlet private weak var responseView: UIImageView!
  @IBOutlet private weak var playerSelector: UISegmentedControl!
    
  @IBAction func enterChoice(_ button: UIButton) {
  }
}

