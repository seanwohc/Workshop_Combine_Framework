struct DivisibleByTen: Error {}

extension Response {
  func restrictedPosition(from int: Int) throws -> HandPosition {
    print(int)
    guard !int.isMultiple(of: 10) else {throw DivisibleByTen()}
    return setHandPosition(for: int % 3)
  }
}
